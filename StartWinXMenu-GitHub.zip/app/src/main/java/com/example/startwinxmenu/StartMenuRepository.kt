package com.example.startwinxmenu

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

data class StartApp(
    val packageName: String,
    val label: String,
    val icon: android.graphics.drawable.Drawable
)

class StartMenuRepository(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("start_winx_menu", Context.MODE_PRIVATE)
    private val pm = context.packageManager

    fun launcherApps(): List<StartApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val ai = info.activityInfo?.applicationInfo ?: return@mapNotNull null
                if (ai.packageName == context.packageName) return@mapNotNull null
                StartApp(
                    ai.packageName,
                    info.loadLabel(pm).toString(),
                    info.loadIcon(pm)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun pinnedPackages(): MutableList<String> {
        return prefs.getStringSet("pinned", emptySet())?.toMutableList() ?: mutableListOf()
    }

    fun pinnedApps(): List<StartApp> {
        val all = launcherApps().associateBy { it.packageName }
        return pinnedPackages().mapNotNull { all[it] }
    }

    fun recentApps(): List<StartApp> {
        val all = launcherApps().associateBy { it.packageName }
        return (prefs.getString("recent", "") ?: "")
            .split('|').filter { it.isNotBlank() }
            .distinct()
            .mapNotNull { all[it] }
    }

    fun togglePinned(packageName: String) {
        val set = pinnedPackages().toMutableSet()
        if (!set.add(packageName)) set.remove(packageName)
        prefs.edit().putStringSet("pinned", set).apply()
    }

    fun pin(packageName: String) {
        val set = pinnedPackages().toMutableSet()
        set.add(packageName)
        prefs.edit().putStringSet("pinned", set).apply()
    }

    fun unpin(packageName: String) {
        val set = pinnedPackages().toMutableSet()
        set.remove(packageName)
        prefs.edit().putStringSet("pinned", set).apply()
    }

    fun clearRecent() {
        prefs.edit().remove("recent").apply()
    }

    fun recordLaunch(packageName: String) {
        val old = (prefs.getString("recent", "") ?: "")
            .split('|').filter { it.isNotBlank() }
        val next = (listOf(packageName) + old.filter { it != packageName }).take(12)
        prefs.edit().putString("recent", next.joinToString("|")).apply()
    }

    fun launch(app: StartApp) {
        val intent = pm.getLaunchIntentForPackage(app.packageName) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        recordLaunch(app.packageName)
        context.startActivity(intent)
    }

    fun ensureDefaults() {
        if (prefs.contains("pinned")) return
        val candidates = launcherApps()
        val defaults = candidates.take(8).map { it.packageName }.toSet()
        prefs.edit().putStringSet("pinned", defaults).apply()
    }
}
