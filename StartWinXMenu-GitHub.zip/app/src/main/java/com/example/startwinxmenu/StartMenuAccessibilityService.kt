package com.example.startwinxmenu

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout

class StartMenuAccessibilityService : AccessibilityService() {

    private var startHandle: View? = null
    private var windowManager: WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
        StartMenuOverlay.bindService(this)
        showStartHandle()
    }

    private fun showStartHandle() {
        if (startHandle != null) return
        val size = (52 * resources.displayMetrics.density).toInt()
        val handle = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 30, 30, 30))
                cornerRadius = 16f * resources.displayMetrics.density
                setStroke((1 * resources.displayMetrics.density).toInt(), Color.argb(100,255,255,255))
            }
            contentDescription = "Start"
            setOnClickListener { StartMenuOverlay.show(this@StartMenuAccessibilityService) }
            setOnLongClickListener {
                StartMenuOverlay.show(this@StartMenuAccessibilityService)
                true
            }
        }
        // A small accessibility overlay handle is the reliable global touch entry point.
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (6 * resources.displayMetrics.density).toInt()
            y = (6 * resources.displayMetrics.density).toInt()
        }
        startHandle = handle
        windowManager?.addView(handle, lp)
        StartMenuOverlay.setHandle(handle)
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        // Optional global shortcut: Volume Down + Volume Up opens Start.
        if (event?.action == KeyEvent.ACTION_DOWN) {
            if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
                event.keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                return false
            }
        }
        return false
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        StartMenuOverlay.hide()
        startHandle?.let { runCatching { windowManager?.removeView(it) } }
        startHandle = null
        StartMenuOverlay.unbindService()
        super.onDestroy()
    }
}
