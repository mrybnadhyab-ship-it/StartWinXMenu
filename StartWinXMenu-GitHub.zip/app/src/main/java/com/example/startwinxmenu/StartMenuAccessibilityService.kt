package com.example.startwinxmenu

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class StartMenuAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // جاهزة لربط الضغط/الإيماءة لاحقاً.
    }

    override fun onInterrupt() {
    }
}
