package com.example.startwinxmenu

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.*
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

object StartMenuOverlay {
    private var windowManager: WindowManager? = null
    private var menuView: MenuView? = null
    private var serviceContext: Context? = null
    private var handle: View? = null

    fun bindService(context: Context) {
        serviceContext = context
        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    fun unbindService() {
        hide()
        serviceContext = null
        windowManager = null
        handle = null
    }

    fun setHandle(view: View) { handle = view }

    fun show(context: Context) {
        if (menuView != null) return
        val c = serviceContext ?: context.applicationContext
        val view = MenuView(c)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        menuView = view
        handle?.visibility = View.GONE
        windowManager?.addView(view, lp)
    }

    fun hide() {
        val v = menuView ?: return
        runCatching { windowManager?.removeView(v) }
        menuView = null
        handle?.visibility = View.VISIBLE
    }

    private class MenuView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val repo = StartMenuRepository(context)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var tab = 0 // 0 pinned, 1 recent, 2 all
        private var apps = emptyList<StartApp>()
        private var downX = 0f
        private var downY = 0f
        private var scroll = 0f
        private var downIndex = -1
        private var longPressed = false
        private val longPress = Runnable {
            if (downIndex >= 0 && downIndex < apps.size) {
                longPressed = true
                manageApp(apps[downIndex])
            }
        }

        private fun dp(v: Float) = v * d
        private fun menuRect(): RectF {
            val w = width.toFloat(); val h = height.toFloat()
            val mw = min(w - dp(20f), dp(760f))
            val mh = min(h - dp(48f), max(dp(410f), h * .68f))
            return RectF((w-mw)/2f, h-mh-dp(20f), (w+mw)/2f, h-dp(20f))
        }

        init {
            repo.ensureDefaults()
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            isFocusable = true
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val r = menuRect()
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(235, 24, 24, 24)
            paint.setShadowLayer(dp(24f), 0f, dp(8f), Color.argb(150,0,0,0))
            c.drawRoundRect(r, dp(20f), dp(20f), paint)
            paint.clearShadowLayer()

            // Header / tabs
            paint.color = Color.WHITE
            paint.textSize = dp(17f)
            paint.textAlign = Paint.Align.LEFT
            c.drawText("Start", r.left+dp(22f), r.top+dp(34f), paint)

            val tabs = arrayOf("مثبت", "الأخيرة", "كل التطبيقات")
            val tabStart = r.left + dp(115f)
            val tabW = (r.width()-dp(135f))/3f
            for (i in tabs.indices) {
                val x = tabStart + i*tabW + tabW/2
                paint.color = if (i==tab) Color.WHITE else Color.argb(155,255,255,255)
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = dp(14f)
                c.drawText(tabs[i], x, r.top+dp(34f), paint)
                if (i==tab) {
                    paint.color = Color.WHITE
                    c.drawRoundRect(x-tabW*.27f, r.top+dp(43f), x+tabW*.27f, r.top+dp(45f), dp(1f),dp(1f),paint)
                }
            }

            paint.color = Color.argb(55,255,255,255)
            c.drawRect(r.left+dp(16f), r.top+dp(54f), r.right-dp(16f), r.top+dp(55f), paint)

            apps = when(tab) {
                0 -> repo.pinnedApps()
                1 -> repo.recentApps()
                else -> repo.launcherApps()
            }
            drawApps(c, r)
            paint.color = Color.argb(150,255,255,255)
            paint.textSize = dp(10f)
            paint.textAlign = Paint.Align.LEFT
            c.drawText(
                when(tab) {
                    0 -> "اضغط لفتح التطبيق • ضغط مطول لإلغاء التثبيت"
                    1 -> "اضغط لفتح التطبيق • ضغط مطول لإزالته من الأخيرة"
                    else -> "اضغط لفتح • ضغط مطول لإضافة إلى مثبت"
                },
                r.left+dp(20f), r.bottom-dp(14f), paint
            )
        }

        private fun drawApps(c: Canvas, r: RectF) {
            val cols = if (width >= dp(700f)) 4 else 3
            val gap = dp(10f)
            val pad = dp(18f)
            val top = r.top+dp(68f)
            val bottom = r.bottom-dp(35f)
            val cellW = (r.width()-2*pad-(cols-1)*gap)/cols
            val cellH = dp(76f)
            val rows = (apps.size + cols - 1)/cols
            val contentH = rows*(cellH+gap)-gap
            val viewportH = bottom-top
            val maxScroll = max(0f, contentH-viewportH)
            scroll = min(max(scroll,0f),maxScroll)

            apps.forEachIndexed { i,a ->
                val row=i/cols; val col=i%cols
                val x=r.left+pad+col*(cellW+gap)
                val y=top+row*(cellH+gap)-scroll
                if (y+cellH < top || y > bottom) return@forEachIndexed
                paint.color = Color.argb(38,255,255,255)
                c.drawRoundRect(x,y,x+cellW,y+cellH,dp(12f),dp(12f),paint)
                val iconBox=dp(42f)
                val ix=x+dp(9f); val iy=y+(cellH-iconBox)/2f
                drawIcon(c,a.icon,RectF(ix,iy,ix+iconBox,iy+iconBox))
                paint.color=Color.WHITE; paint.textAlign=Paint.Align.LEFT; paint.textSize=dp(12f)
                val label=trimLabel(a.label, if(cellW<dp(150f)) 15 else 20)
                c.drawText(label, ix+iconBox+dp(8f), y+cellH/2f+dp(4f), paint)
            }
        }

        private fun trimLabel(s:String,n:Int):String = if(s.length<=n) s else s.take(n-1)+"…"

        private fun drawIcon(c:Canvas, d:Drawable, dst:RectF) {
            d.bounds=Rect(dst.left.toInt(),dst.top.toInt(),dst.right.toInt(),dst.bottom.toInt())
            d.draw(c)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val r=menuRect()
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX=e.x; downY=e.y; downIndex=hitIndex(e.x,e.y,r)
                    longPressed = false
                    removeCallbacks(longPress)
                    if (downIndex >= 0 && downIndex < apps.size) postDelayed(longPress, 550L)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy=downY-e.y
                    if(kotlin.math.abs(dy)>2f) {
                        removeCallbacks(longPress)
                        scroll += dy; downY=e.y; invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    removeCallbacks(longPress)
                    if (downX < r.left || downX > r.right || downY < r.top || downY > r.bottom) { hide(); return true }
                    if (longPressed) { downIndex = -1; return true }
                    // tabs
                    if(e.y>=r.top && e.y<r.top+dp(55f)) {
                        val tabStart=r.left+dp(115f); val tabW=(r.width()-dp(135f))/3f
                        if(e.x>=tabStart && e.x<tabStart+3*tabW) { tab=((e.x-tabStart)/tabW).toInt().coerceIn(0,2); scroll=0f; invalidate(); return true }
                    }
                    val idx=hitIndex(e.x,e.y,r)
                    if(idx>=0 && idx==downIndex && idx<apps.size) {
                        launch(apps[idx])
                    }
                    downIndex = -1
                    return true
                }
            }
            return true
        }

        private fun hitIndex(x:Float,y:Float,r:RectF):Int {
            val cols=if(width>=dp(700f))4 else 3
            val gap=dp(10f); val pad=dp(18f); val top=r.top+dp(68f); val cellW=(r.width()-2*pad-(cols-1)*gap)/cols; val cellH=dp(76f)
            val xx=x-(r.left+pad); val yy=y-top+scroll
            if(xx<0 || yy<0) return -1
            val col=(xx/(cellW+gap)).toInt(); val row=(yy/(cellH+gap)).toInt()
            if(col !in 0 until cols) return -1
            val localX=xx-col*(cellW+gap); val localY=yy-row*(cellH+gap)
            if(localX>cellW || localY>cellH) return -1
            return row*cols+col
        }

        private fun manageApp(app: StartApp) {
            when (tab) {
                0 -> {
                    repo.unpin(app.packageName)
                    Toast.makeText(context, "تم إلغاء تثبيت ${app.label}", Toast.LENGTH_SHORT).show()
                }
                1 -> {
                    // Recent is rebuilt from the saved launch history; removing one item
                    // keeps the other recent entries intact.
                    val kept = repo.recentApps().filter { it.packageName != app.packageName }
                    repo.clearRecent()
                    kept.reversed().forEach { repo.recordLaunch(it.packageName) }
                    Toast.makeText(context, "تمت إزالة ${app.label} من الأخيرة", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    repo.pin(app.packageName)
                    Toast.makeText(context, "تم تثبيت ${app.label}", Toast.LENGTH_SHORT).show()
                }
            }
            invalidate()
        }

        private fun launch(app:StartApp) {
            repo.launch(app)
            hide()
        }
    }
}
