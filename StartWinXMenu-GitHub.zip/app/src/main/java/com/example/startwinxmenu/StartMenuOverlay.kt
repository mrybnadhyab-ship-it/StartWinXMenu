package com.example.startwinxmenu

import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.PopupWindow

object StartMenuOverlay {

    private var popup: PopupWindow? = null

    fun show(context: Context) {
        if (popup?.isShowing == true) return

        val view = MenuView(context)

        popup = PopupWindow(
            view,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            true
        ).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            isOutsideTouchable = true
            elevation = 30f
            setOnDismissListener {
                popup = null
            }
        }

        popup!!.showAtLocation(
            view,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
            0,
            0
        )
    }

    fun hide() {
        popup?.dismiss()
        popup = null
    }

    private class MenuView(context: Context) : View(context) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val density = resources.displayMetrics.density

        private val pinned = listOf(
            "الآلة الحاسبة",
            "Mail",
            "To Do",
            "التقويم",
            "Excel",
            "PowerPoint",
            "Whiteboard",
            "OneNote"
        )

        private val recent = listOf(
            "Opera",
            "Google",
            "Lite",
            "Play متجر",
            "MiX هذا الكمبيوتر",
            "هايبر درويد",
            "واتساب",
            "Net Blocker"
        )

        private fun dp(value: Float): Float = value * density

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val w = width.toFloat()
            val h = height.toFloat()

            val menuWidth = w * 0.958f
            val menuHeight = h * 0.50f

            val left = (w - menuWidth) / 2f
            val bottom = h - dp(18f)
            val top = bottom - menuHeight
            val radius = dp(20f)

            paint.style = Paint.Style.FILL
            paint.color = Color.argb(232, 18, 18, 18)

            canvas.drawRoundRect(
                left,
                top,
                left + menuWidth,
                bottom,
                radius,
                radius,
                paint
            )

            val dividerX = left + menuWidth * 0.67f

            paint.color = Color.argb(105, 80, 80, 80)

            canvas.drawRect(
                dividerX,
                top + dp(1f),
                dividerX + dp(1f),
                bottom - dp(1f),
                paint
            )

            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = dp(19f)

            canvas.drawText(
                "مثبت",
                left + menuWidth * 0.335f,
                top + dp(31f),
                paint
            )

            paint.textAlign = Paint.Align.RIGHT
            paint.textSize = dp(20f)

            canvas.drawText(
                "الأخيرة",
                left + menuWidth - dp(55f),
                top + dp(31f),
                paint
            )

            paint.textAlign = Paint.Align.CENTER
            paint.textSize = dp(30f)

            canvas.drawText(
                "☰",
                left + menuWidth - dp(25f),
                top + dp(34f),
                paint
            )

            drawPinned(canvas, left, top, menuWidth)
            drawRecent(canvas, left, top, menuWidth)
        }

        private fun drawPinned(
            canvas: Canvas,
            left: Float,
            top: Float,
            menuWidth: Float
        ) {
            val sectionWidth = menuWidth * 0.67f
            val padding = dp(14f)
            val gap = dp(10f)

            val gridTop = top + dp(55f)
            val gridBottom = top + height * 0.50f - dp(10f)

            val cellWidth =
                (sectionWidth - padding * 2f - gap) / 2f

            val cellHeight =
                (gridBottom - gridTop - gap * 3f) / 4f

            pinned.forEachIndexed { index, title ->

                val column = index % 2
                val row = index / 2

                val x =
                    left +
                    padding +
                    column * (cellWidth + gap)

                val y =
                    gridTop +
                    row * (cellHeight + gap)

                paint.color =
                    Color.argb(235, 27, 27, 27)

                canvas.drawRoundRect(
                    x,
                    y,
                    x + cellWidth,
                    y + cellHeight,
                    dp(13f),
                    dp(13f),
                    paint
                )

                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = dp(15f)

                canvas.drawText(
                    title,
                    x + cellWidth / 2f,
                    y + cellHeight / 2f + dp(5f),
                    paint
                )
            }
        }

        private fun drawRecent(
            canvas: Canvas,
            left: Float,
            top: Float,
            menuWidth: Float
        ) {
            val sectionLeft = left + menuWidth * 0.67f
            val sectionWidth = menuWidth * 0.33f

            recent.forEachIndexed { index, title ->

                val y =
                    top +
                    dp(68f) +
                    index * dp(52f)

                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.RIGHT
                paint.textSize = dp(15f)

                canvas.drawText(
                    title,
                    sectionLeft + sectionWidth - dp(48f),
                    y + dp(29f),
                    paint
                )

                paint.textAlign = Paint.Align.CENTER
                paint.textSize = dp(21f)

                val symbol = when (index) {
                    0 -> "O"
                    1 -> "G"
                    2 -> "●"
                    3 -> "◇"
                    4 -> "▣"
                    5 -> "▦"
                    6 -> "●"
                    else -> "▣"
                }

                canvas.drawText(
                    symbol,
                    sectionLeft + sectionWidth - dp(20f),
                    y + dp(30f),
                    paint
                )
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {

            if (event.action == MotionEvent.ACTION_UP) {

                val w = width.toFloat()
                val h = height.toFloat()

                val menuWidth = w * 0.958f
                val menuHeight = h * 0.50f

                val left = (w - menuWidth) / 2f
                val bottom = h - dp(18f)
                val top = bottom - menuHeight

                if (
                    event.x < left ||
                    event.x > left + menuWidth ||
                    event.y < top ||
                    event.y > bottom
                ) {
                    StartMenuOverlay.hide()
                }
            }

            return true
        }
    }
}
