package com.example.startwinxmenu

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        root.addView(TextView(this).apply {
            text = "Start WinX Menu"
            textSize = 24f
            gravity = Gravity.CENTER
        })

        root.addView(Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        })

        root.addView(Button(this).apply {
            text = "إظهار قائمة ابدأ"
            setOnClickListener {
                StartMenuOverlay.show(this@MainActivity)
            }
        })

        setContentView(root)
    }
}
