package com.example.startwinxmenu

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40,40,40,40)
        }
        root.addView(TextView(this).apply {
            text = "Start WinX Menu"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "قائمة ابدأ عائمة تعمل فوق التطبيقات عبر Accessibility Overlay"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0,12,0,20)
        })
        root.addView(Button(this).apply {
            text = "تفعيل خدمة Start WinX"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "إظهار قائمة ابدأ الآن"
            setOnClickListener {
                if (isAccessibilityEnabled()) StartMenuOverlay.show(this@MainActivity)
                else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "إعدادات الوصول السريع"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        })
        setContentView(root)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, StartMenuAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
