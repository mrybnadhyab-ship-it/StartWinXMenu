# StartWinXMenu

مشروع Android مستقل لقائمة ابدأ بدون Taskbar.

## GitHub Actions

المشروع يحتوي على:

`.github/workflows/build.yml`

ويعمل تلقائياً عند:
- Push إلى `main`
- أو تشغيل `workflow_dispatch` يدوياً.

يستخدم:
- Ubuntu latest
- Java 17 Temurin
- Gradle 8.13
- Android Gradle Plugin 8.7.3

بعد نجاح البناء ستجد APK في:

Actions → Build StartWinXMenu → آخر تشغيل → Artifacts

اسم الـArtifact:

`StartWinXMenu-debug-apk`

## الاستيراد إلى GitHub

ارفع محتويات هذا المشروع إلى جذر Repository جديد.
لا ترفع ملف ZIP نفسه داخل Repository إذا أردت أن يعمل GitHub Actions مباشرة.

يجب أن يكون الشكل:

app/
.github/
build.gradle
settings.gradle
gradle.properties

ثم اعمل Commit إلى main.

## ملاحظة

هذه النسخة تحتوي على قائمة Overlay تجريبية بدون Taskbar، مع زر من التطبيق لإظهارها. خدمة Accessibility موجودة كأساس للتوسعة لاحقاً، لكن الضغط المطول العالمي لم يُفعّل حتى لا يعترض لمس التطبيقات الأخرى.
