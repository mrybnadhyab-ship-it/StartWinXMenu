package com.example.startwinxmenu

import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity

class AppPickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        root.addView(list)

        val pinned = SettingsStore.pinned(this)
        AppRepository.launchableApps(this).forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val icon = ImageView(this).apply {
                setImageDrawable(AppRepository.icon(this@AppPickerActivity, app))
            }
            row.addView(icon, LinearLayout.LayoutParams(56, 56))
            val check = CheckBox(this).apply {
                text = app.label
                textSize = 16f
                isChecked = pinned.any { it.key == app.key }
                setOnCheckedChangeListener { _, checked ->
                    if (checked) SettingsStore.updatePinnedEntry(this@AppPickerActivity, app)
                    else SettingsStore.removePinned(this@AppPickerActivity, app.key)
                }
            }
            row.addView(check, LinearLayout.LayoutParams(0, 64, 1f))
            list.addView(row)
        }

        setContentView(root)
    }
}
