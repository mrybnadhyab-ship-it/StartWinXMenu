package com.example.startwinxmenu

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings

object AppRepository {

    fun launchableApps(context: Context): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                val ai = ri.activityInfo ?: return@mapNotNull null
                if (ai.packageName == context.packageName) return@mapNotNull null
                AppEntry(
                    ai.packageName,
                    ai.name,
                    ri.loadLabel(context.packageManager)?.toString() ?: ai.packageName
                )
            }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
    }

    fun resolve(context: Context, entry: AppEntry): AppEntry? {
        val info = runCatching {
            context.packageManager.getActivityInfo(
                ComponentName(entry.packageName, entry.activityName), 0
            )
        }.getOrNull() ?: return null

        return entry.copy(label = if (entry.label.isBlank()) info.loadLabel(context.packageManager).toString() else entry.label)
    }

    fun icon(context: Context, entry: AppEntry): Drawable? {
        entry.iconUri?.let {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(it))?.use { input ->
                    Drawable.createFromStream(input, "custom")
                }
            }.getOrNull()?.let { return it }
        }
        return runCatching {
            context.packageManager.getActivityIcon(
                ComponentName(entry.packageName, entry.activityName)
            )
        }.getOrNull()
    }

    fun launch(context: Context, entry: AppEntry) {
        val intent = Intent().apply {
            component = ComponentName(entry.packageName, entry.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
        SettingsStore.addRecent(context, entry)
    }

    fun openOverlaySettings(context: Context) {
        context.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
