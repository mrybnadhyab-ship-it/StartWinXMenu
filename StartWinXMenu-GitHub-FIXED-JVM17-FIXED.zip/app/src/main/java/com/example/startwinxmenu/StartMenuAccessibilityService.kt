package com.example.startwinxmenu

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class StartMenuAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        SettingsStore.ensureDefaults(this, AppRepository.launchableApps(this))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            if (pkg == packageName) return

            val app = AppRepository.launchableApps(this).firstOrNull { it.packageName == pkg }
            if (app != null) {
                val current = SettingsStore.recent(this).firstOrNull { it.key == app.key }
                SettingsStore.addRecent(this, current ?: app)
                if (StartMenuOverlay.isShowing()) StartMenuOverlay.refresh(this)
            }
        }
    }

    override fun onInterrupt() {
    }

    override fun onDestroy() {
        StartMenuOverlay.hide()
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW = "com.example.startwinxmenu.SHOW_START_MENU"
        const val ACTION_HIDE = "com.example.startwinxmenu.HIDE_START_MENU"
        var instance: StartMenuAccessibilityService? = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> StartMenuOverlay.show(this)
            ACTION_HIDE -> StartMenuOverlay.hide()
        }
        return START_STICKY
    }
}
