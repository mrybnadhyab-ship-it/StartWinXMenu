package com.example.startwinxmenu

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

object SettingsStore {
    private const val PREFS = "start_winx_settings"
    private const val PINNED = "pinned"
    private const val RECENT = "recent"
    private const val MENU_WIDTH = "menu_width"
    private const val MENU_HEIGHT = "menu_height"
    private const val TILE_SIZE = "tile_size"
    private const val ICON_SIZE = "icon_size"
    private const val TEXT_SIZE = "text_size"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun menuWidth(context: Context) = prefs(context).getFloat(MENU_WIDTH, 0.958f)
    fun menuHeight(context: Context) = prefs(context).getFloat(MENU_HEIGHT, 0.50f)
    fun tileSize(context: Context) = prefs(context).getInt(TILE_SIZE, 72)
    fun iconSize(context: Context) = prefs(context).getInt(ICON_SIZE, 32)
    fun textSize(context: Context) = prefs(context).getFloat(TEXT_SIZE, 14f)

    fun saveVisual(context: Context, width: Float, height: Float, tile: Int, icon: Int, text: Float) {
        prefs(context).edit()
            .putFloat(MENU_WIDTH, width)
            .putFloat(MENU_HEIGHT, height)
            .putInt(TILE_SIZE, tile)
            .putInt(ICON_SIZE, icon)
            .putFloat(TEXT_SIZE, text)
            .apply()
    }

    private fun encode(items: List<AppEntry>): String {
        val a = JSONArray()
        items.forEach {
            a.put(JSONObject().apply {
                put("package", it.packageName)
                put("activity", it.activityName)
                put("label", it.label)
                put("color", it.tileColor)
                put("iconUri", it.iconUri ?: JSONObject.NULL)
            })
        }
        return a.toString()
    }

    private fun decode(raw: String): MutableList<AppEntry> {
        val out = mutableListOf<AppEntry>()
        runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += AppEntry(
                    o.getString("package"),
                    o.getString("activity"),
                    o.optString("label"),
                    o.optInt("color", 0),
                    if (o.isNull("iconUri")) null else o.optString("iconUri")
                )
            }
        }
        return out
    }

    fun pinned(context: Context): MutableList<AppEntry> =
        decode(prefs(context).getString(PINNED, "[]") ?: "[]")

    fun recent(context: Context): MutableList<AppEntry> =
        decode(prefs(context).getString(RECENT, "[]") ?: "[]")

    fun savePinned(context: Context, list: List<AppEntry>) =
        prefs(context).edit().putString(PINNED, encode(list)).apply()

    fun saveRecent(context: Context, list: List<AppEntry>) =
        prefs(context).edit().putString(RECENT, encode(list)).apply()

    fun ensureDefaults(context: Context, apps: List<AppEntry>) {
        if (pinned(context).isNotEmpty()) return
        savePinned(context, apps.take(8))
    }

    fun addRecent(context: Context, item: AppEntry) {
        val list = recent(context)
        list.removeAll { it.key == item.key }
        list.add(0, item)
        saveRecent(context, list.take(8))
    }

    fun updatePinnedEntry(context: Context, item: AppEntry) {
        val list = pinned(context)
        val i = list.indexOfFirst { it.key == item.key }
        if (i >= 0) list[i] = item else list.add(item)
        savePinned(context, list)
    }

    fun removePinned(context: Context, key: String) {
        savePinned(context, pinned(context).filterNot { it.key == key })
    }

    fun resetPinned(context: Context, apps: List<AppEntry>) {
        savePinned(context, apps.take(8))
    }

    fun colorDefault(): Int = Color.rgb(38, 38, 38)
}
