package com.example.startwinxmenu

data class AppEntry(
    val packageName: String,
    val activityName: String,
    var label: String,
    var tileColor: Int = 0,
    var iconUri: String? = null
) {
    val key: String get() = "$packageName/$activityName"
}
