package com.example.startwinxmenu

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    private lateinit var widthSeek: SeekBar
    private lateinit var heightSeek: SeekBar
    private lateinit var tileSeek: SeekBar
    private lateinit var iconSeek: SeekBar
    private lateinit var textSeek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 28)
        }

        root.addView(TextView(this).apply {
            text = "Start WinX Menu"
            textSize = 25f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "اضغط مطولاً على أي تطبيق مثبت لتخصيصه. التخصيصات تُحفظ تلقائياً."
            textSize = 14f
            gravity = Gravity.CENTER
        })

        root.addView(Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })

        root.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "إظهار قائمة ابدأ الآن"
            setOnClickListener {
                if (StartMenuAccessibilityService.instance != null) {
                    StartMenuOverlay.show(this@MainActivity)
                } else {
                    Toast.makeText(this@MainActivity, "فعّل خدمة Start WinX Menu من إعدادات إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
                }
            }
        })

        addSeek(root, "عرض القائمة", 80, 100, (SettingsStore.menuWidth(this) * 100).toInt()) {
            saveVisual()
        }.also { widthSeek = it }

        addSeek(root, "ارتفاع القائمة", 35, 85, (SettingsStore.menuHeight(this) * 100).toInt()) {
            saveVisual()
        }.also { heightSeek = it }

        addSeek(root, "حجم المربع", 52, 110, SettingsStore.tileSize(this)) {
            saveVisual()
        }.also { tileSeek = it }

        addSeek(root, "حجم الأيقونة", 20, 60, SettingsStore.iconSize(this)) {
            saveVisual()
        }.also { iconSeek = it }

        addSeek(root, "حجم النص", 10, 24, SettingsStore.textSize(this).toInt()) {
            saveVisual()
        }.also { textSeek = it }

        root.addView(Button(this).apply {
            text = "إدارة التطبيقات المثبتة"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, AppPickerActivity::class.java))
            }
        })

        root.addView(Button(this).apply {
            text = "إعادة قائمة مثبت إلى الوضع الافتراضي"
            setOnClickListener {
                SettingsStore.resetPinned(this@MainActivity, AppRepository.launchableApps(this@MainActivity))
                Toast.makeText(this@MainActivity, "تمت إعادة التطبيقات المثبتة", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(root)
    }

    private fun addSeek(
        root: LinearLayout,
        title: String,
        min: Int,
        max: Int,
        value: Int,
        listener: () -> Unit
    ): SeekBar {
        val label = TextView(this).apply {
            text = "$title: $value"
            textSize = 14f
        }
        root.addView(label)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: ${p + min}"
                    if (fromUser) listener()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek)
        return seek
    }

    private fun saveVisual() {
        SettingsStore.saveVisual(
            this,
            widthSeek.progress / 100f + 0.80f,
            heightSeek.progress / 100f + 0.35f,
            tileSeek.progress + 52,
            iconSeek.progress + 20,
            textSeek.progress + 10f
        )
        if (StartMenuOverlay.isShowing()) StartMenuOverlay.refresh(this)
    }
}
