package com.example.startwinxmenu

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StartMenuTriggerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            StartMenuAccessibilityService.ACTION_SHOW -> StartMenuOverlay.showFromReceiver(context)
            StartMenuAccessibilityService.ACTION_HIDE -> StartMenuOverlay.hide()
        }
    }
}
