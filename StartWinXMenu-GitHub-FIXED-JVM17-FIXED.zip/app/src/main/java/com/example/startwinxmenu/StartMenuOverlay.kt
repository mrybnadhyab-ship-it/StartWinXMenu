package com.example.startwinxmenu

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

object StartMenuOverlay {
    private var windowManager: WindowManager? = null
    private var root: FrameLayout? = null
    private var serviceContext: Context? = null

    fun isShowing() = root != null

    fun show(service: AccessibilityService) {
        serviceContext = service
        showInternal(service)
    }

    fun showFromReceiver(context: Context) {
        StartMenuAccessibilityService.instance?.let { show(it) }
    }

    fun show(context: Context) {
        if (context is AccessibilityService) {
            show(context)
        } else {
            context.sendBroadcast(
                Intent(StartMenuAccessibilityService.ACTION_SHOW).setPackage(context.packageName)
            )
        }
    }

    private fun showInternal(context: Context) {
        if (root != null) return
        serviceContext = context

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val r = FrameLayout(context)
        r.setBackgroundColor(Color.TRANSPARENT)

        val menu = buildMenu(context)
        val lp = FrameLayout.LayoutParams(
            menuWidthPx(context),
            menuHeightPx(context),
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = dp(context, 18) }
        r.addView(menu, lp)

        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP &&
                !isInside(menu, e.x, e.y, lp)) {
                hide()
            }
            true
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (context is AccessibilityService)
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        runCatching {
            wm.addView(r, params)
            windowManager = wm
            root = r
        }
    }

    private fun isInside(
        view: View, x: Float, y: Float, lp: FrameLayout.LayoutParams
    ): Boolean {
        val l = lp.leftMargin
        val t = view.parent.let { (root as? View)?.height?.minus(lp.height + dp(view.context, 18)) ?: 0 }
        return x in l.toFloat()..(l + lp.width).toFloat() &&
            y in t.toFloat()..(t + lp.height).toFloat()
    }

    fun refresh(context: Context) {
        val r = root ?: return
        val parent = r.getChildAt(0)
        r.removeView(parent)
        val menu = buildMenu(context)
        val lp = FrameLayout.LayoutParams(
            menuWidthPx(context), menuHeightPx(context),
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = dp(context, 18) }
        r.addView(menu, lp)
    }

    fun hide() {
        val r = root ?: return
        runCatching { windowManager?.removeView(r) }
        root = null
        windowManager = null
        serviceContext = null
    }

    private fun buildMenu(context: Context): View {
        val menu = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10))
            background = GradientDrawable().apply {
                setColor(Color.argb(245, 18, 18, 18))
                cornerRadius = dp(context, 20).toFloat()
            }
            elevation = dp(context, 12).toFloat()
        }

        val pinnedColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        val recentColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 12), 0, 0, 0)
        }

        val header = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val pinnedTitle = TextView(context).apply {
            text = "مثبت"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        header.addView(pinnedTitle, LinearLayout.LayoutParams(0, dp(context, 42), 1f))
        val menuButton = TextView(context).apply {
            text = "☰"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener {
                context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        header.addView(menuButton, LinearLayout.LayoutParams(dp(context, 48), dp(context, 42)))
        pinnedColumn.addView(header)

        val grid = GridLayout(context).apply {
            columnCount = 2
            useDefaultMargins = false
        }
        val pinned = SettingsStore.pinned(context)
        SettingsStore.ensureDefaults(context, AppRepository.launchableApps(context))
        val finalPinned = SettingsStore.pinned(context)
        finalPinned.forEach { entry ->
            grid.addView(tile(context, entry), GridLayout.LayoutParams().apply {
                width = 0
                height = dp(context, SettingsStore.tileSize(context))
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(context, 4), dp(context, 4), dp(context, 4), dp(context, 4))
            })
        }
        pinnedColumn.addView(grid, LinearLayout.LayoutParams(0, 0, 1f))

        recentColumn.addView(TextView(context).apply {
            text = "الأخيرة"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(context, 42)))

        val recentList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        SettingsStore.recent(context).forEach { entry ->
            recentList.addView(recentRow(context, entry))
        }
        recentColumn.addView(recentList, LinearLayout.LayoutParams(-1, 0, 1f))

        menu.addView(pinnedColumn, LinearLayout.LayoutParams(0, -1, 0.67f))
        menu.addView(recentColumn, LinearLayout.LayoutParams(0, -1, 0.33f))
        return menu
    }

    private fun tile(context: Context, entry: AppEntry): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(context, 8), dp(context, 5), dp(context, 8), dp(context, 5))
            background = GradientDrawable().apply {
                setColor(if (entry.tileColor != 0) entry.tileColor else SettingsStore.colorDefault())
                cornerRadius = dp(context, 13).toFloat()
            }
            setOnClickListener {
                AppRepository.launch(context, entry)
                hide()
            }
            setOnLongClickListener {
                context.startActivity(
                    Intent(context, CustomizeActivity::class.java)
                        .putExtra(CustomizeActivity.EXTRA_KEY, entry.key)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            }
        }
        val icon = ImageView(context).apply {
            setImageDrawable(AppRepository.icon(context, entry))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(context, SettingsStore.iconSize(context)), -1))
        row.addView(TextView(context).apply {
            text = entry.label
            textSize = SettingsStore.textSize(context)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -1, 1f))
        return row
    }

    private fun recentRow(context: Context, entry: AppEntry): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(context, 4), dp(context, 2), 0, dp(context, 2))
            setOnClickListener {
                AppRepository.launch(context, entry)
                hide()
            }
        }
        val icon = ImageView(context).apply {
            setImageDrawable(AppRepository.icon(context, entry))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(context, SettingsStore.iconSize(context)), dp(context, 42)))
        row.addView(TextView(context).apply {
            text = entry.label
            textSize = SettingsStore.textSize(context)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, dp(context, 42), 1f))
        return row
    }

    private fun menuWidthPx(context: Context): Int {
        val w = context.resources.displayMetrics.widthPixels
        return (w * SettingsStore.menuWidth(context)).roundToInt()
    }

    private fun menuHeightPx(context: Context): Int {
        val h = context.resources.displayMetrics.heightPixels
        return (h * SettingsStore.menuHeight(context)).roundToInt()
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).roundToInt()
}
