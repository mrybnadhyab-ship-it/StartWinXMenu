package com.example.startwinxmenu

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class CustomizeActivity : ComponentActivity() {
    companion object { const val EXTRA_KEY = "entry_key" }

    private lateinit var entry: AppEntry
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        entry.iconUri = uri.toString()
        SettingsStore.updatePinnedEntry(this, entry)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val key = intent.getStringExtra(EXTRA_KEY) ?: run { finish(); return }
        entry = SettingsStore.pinned(this).firstOrNull { it.key == key }
            ?: AppRepository.launchableApps(this).firstOrNull { it.key == key }
            ?: run { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 28)
        }

        root.addView(TextView(this).apply {
            text = "تخصيص: ${entry.label}"
            textSize = 23f
        })

        val name = EditText(this).apply {
            hint = "اسم التطبيق"
            setText(entry.label)
        }
        root.addView(name)

        root.addView(Button(this).apply {
            text = "حفظ الاسم"
            setOnClickListener {
                entry.label = name.text.toString().trim().ifBlank { entry.label }
                SettingsStore.updatePinnedEntry(this@CustomizeActivity, entry)
                Toast.makeText(this@CustomizeActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(TextView(this).apply {
            text = "لون المربع"
            textSize = 16f
        })

        val colors = listOf(
            "داكن" to Color.rgb(38,38,38),
            "أزرق" to Color.rgb(35,75,125),
            "أخضر" to Color.rgb(35,105,70),
            "أحمر" to Color.rgb(120,45,45),
            "بنفسجي" to Color.rgb(85,55,120),
            "رمادي" to Color.rgb(75,75,75)
        )
        colors.forEach { (title, color) ->
            root.addView(Button(this).apply {
                text = title
                setOnClickListener {
                    entry.tileColor = color
                    SettingsStore.updatePinnedEntry(this@CustomizeActivity, entry)
                    Toast.makeText(this@CustomizeActivity, "تم تغيير اللون", Toast.LENGTH_SHORT).show()
                }
            })
        }

        root.addView(Button(this).apply {
            text = "استخدام أيقونة التطبيق الأصلية"
            setOnClickListener {
                entry.iconUri = null
                SettingsStore.updatePinnedEntry(this@CustomizeActivity, entry)
            }
        })

        root.addView(Button(this).apply {
            text = "اختيار صورة من الهاتف كأيقونة"
            setOnClickListener {
                picker.launch(arrayOf("image/png", "image/jpeg", "image/webp"))
            }
        })

        root.addView(Button(this).apply {
            text = if (SettingsStore.pinned(this).any { it.key == entry.key }) "إزالة من مثبت" else "إضافة إلى مثبت"
            setOnClickListener {
                val list = SettingsStore.pinned(this@CustomizeActivity)
                if (list.any { it.key == entry.key }) {
                    SettingsStore.removePinned(this@CustomizeActivity, entry.key)
                    Toast.makeText(this@CustomizeActivity, "تمت الإزالة", Toast.LENGTH_SHORT).show()
                } else {
                    SettingsStore.updatePinnedEntry(this@CustomizeActivity, entry)
                    Toast.makeText(this@CustomizeActivity, "تمت الإضافة", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        })

        root.addView(Button(this).apply {
            text = "إغلاق"
            setOnClickListener { finish() }
        })

        setContentView(root)
    }
}
